`timescale 1ns / 1ps

module running_time(
	input wire clk,
	input wire rst_n,
	input wire set_time,
	
	input wire [4:0] inc_hours, 
	input wire [5:0] inc_minutes,

	output reg [4:0] running_hours, 
	output reg [5:0] running_minutes
	
	);

	// counts from 0-7 for the number of clks (8 clks is one second)
	reg [2:0] counter; 
	// counts to 59 for seconds
	reg [5:0] seconds;
	
	always@(posedge clk or negedge rst_n) begin
		if (!rst_n) begin 				//required so all values are reset when rst_n flag is triggered
			counter 	<= 3'b000;
			seconds 	<= 6'b000000;
			running_minutes <= 6'b000000;
			running_hours   <= 5'b00000;
		end else if (set_time) begin // load the running clock with the values that are being inc if set_time goes high so the incremented time becomes the new running time
			running_hours   <= inc_hours;
			running_minutes <= inc_minutes;
			counter 	<= 3'b000;
			seconds 	<= 6'b000000;	
		
		end else if (counter == 3'b111) begin        // if counter hits 7 clks (1 sec) -> 0
    			counter <= 3'b000;
    			if (seconds == 6'b111011) begin           
        			seconds <= 6'b000000;
       				if (running_minutes == 6'b111011) begin
            				running_minutes <= 6'b000000;
            				if (running_hours == 5'b10111) begin
		 				running_hours <= 5'b00000;
            				end else begin 
						running_hours <= running_hours + 5'b000001;
					end
        			end else begin
					running_minutes <= running_minutes + 6'b000001;
				end
    			end else begin 
				seconds <= seconds + 6'b000001;
			end
		end else begin
    			counter <= counter + 3'b001;
		end
	end
endmodule
