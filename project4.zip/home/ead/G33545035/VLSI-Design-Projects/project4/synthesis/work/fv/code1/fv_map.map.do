
//input ports
add mapped point clk clk -type PI PI
add mapped point rst_n rst_n -type PI PI
add mapped point a[1] a[1] -type PI PI
add mapped point a[0] a[0] -type PI PI
add mapped point b[1] b[1] -type PI PI
add mapped point b[0] b[0] -type PI PI
add mapped point enable enable -type PI PI

//output ports
add mapped point c[1] c[1] -type PO PO
add mapped point c[0] c[0] -type PO PO

//inout ports




//Sequential Pins
add mapped point c[1]/q c_reg[1]/Q -type DFF DFF
add mapped point c[0]/q c_reg[0]/Q -type DFF DFF



//Black Boxes



//Empty Modules as Blackboxes
