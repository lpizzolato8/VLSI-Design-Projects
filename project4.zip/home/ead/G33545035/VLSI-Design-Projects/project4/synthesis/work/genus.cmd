# Cadence Genus(TM) Synthesis Solution, Version 25.10-p002_1, built Apr 17 2025 15:35:38

# Date: Fri Oct 09 20:22:34 2026
# Host: shell01 (x86_64 w/Linux 4.18.0-553.158.1.el8_10.x86_64) (14cores*56cpus*2physical cpus*Intel(R) Xeon(R) Gold 6132 CPU @ 2.60GHz 19712KB)
# OS:   Rocky Linux 8.10 (Green Obsidian)

ls
cd ..
ls
scripts/synthesis_code0.tcl
run scripts/synthesis_code0.tcl
source scripts/synthesis_code0.tcl
