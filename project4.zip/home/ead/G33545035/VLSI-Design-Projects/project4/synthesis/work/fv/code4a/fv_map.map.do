
//input ports
add mapped point clk clk -type PI PI
add mapped point rst_n rst_n -type PI PI
add mapped point set_time set_time -type PI PI
add mapped point increment_hour increment_hour -type PI PI
add mapped point increment_minute increment_minute -type PI PI
add mapped point set_alarm_time set_alarm_time -type PI PI
add mapped point enable_alarm enable_alarm -type PI PI
add mapped point alarm_off alarm_off -type PI PI

//output ports
add mapped point time_hours[4] time_hours[4] -type PO PO
add mapped point time_hours[3] time_hours[3] -type PO PO
add mapped point time_hours[2] time_hours[2] -type PO PO
add mapped point time_hours[1] time_hours[1] -type PO PO
add mapped point time_hours[0] time_hours[0] -type PO PO
add mapped point time_minutes[5] time_minutes[5] -type PO PO
add mapped point time_minutes[4] time_minutes[4] -type PO PO
add mapped point time_minutes[3] time_minutes[3] -type PO PO
add mapped point time_minutes[2] time_minutes[2] -type PO PO
add mapped point time_minutes[1] time_minutes[1] -type PO PO
add mapped point time_minutes[0] time_minutes[0] -type PO PO
add mapped point alarm alarm -type PO PO
add mapped point alarm_enabled alarm_enabled -type PO PO

//inout ports




//Sequential Pins
add mapped point time_hours_q[3]/q time_hours_q_reg[3]/Q -type DFF DFF
add mapped point time_hours_q[4]/q time_hours_q_reg[4]/Q -type DFF DFF
add mapped point time_hours_q[2]/q time_hours_q_reg[2]/Q -type DFF DFF
add mapped point time_minutes_q[5]/q time_minutes_q_reg[5]/Q -type DFF DFF
add mapped point time_hours_q[1]/q time_hours_q_reg[1]/Q -type DFF DFF
add mapped point time_hours_q[0]/q time_hours_q_reg[0]/Q -type DFF DFF
add mapped point time_minutes_q[4]/q time_minutes_q_reg[4]/Q -type DFF DFF
add mapped point time_minutes_q[3]/q time_minutes_q_reg[3]/Q -type DFF DFF
add mapped point time_minutes_q[2]/q time_minutes_q_reg[2]/Q -type DFF DFF
add mapped point time_minutes_q[1]/q time_minutes_q_reg[1]/Q -type DFF DFF
add mapped point time_minutes_q[0]/q time_minutes_q_reg[0]/Q -type DFF DFF



//Black Boxes
add mapped point U_counter U_counter -type BBOX BBOX



//Empty Modules as Blackboxes
